"use client";

import {
  Box,
  Container,
  Grid,
  Typography,
  Tooltip,
} from "@mui/material";
import {
  Settings as SettingsIcon,
  Security as SecurityIcon,
  Gavel as GavelIcon,
  Assignment as TaskIcon,
  Room as LocationIcon,
  Schedule as ScheduleIcon,
} from "@mui/icons-material";
import ParticleBackground from "../components/particle-background";
import ScrollAnimation from "../components/scroll-animation";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState, useRef } from "react";

// Custom Tooltip styling
const CustomTooltip = ({ title, placement, children }) => (
  <Tooltip
    title={title}
    placement={placement}
    arrow
    componentsProps={{
      tooltip: {
        sx: {
          background: "linear-gradient(135deg, #7c3aed 0%, #4c1d95 100%)",
          color: "#e9d5ff",
          fontSize: "0.9rem",
          fontWeight: "medium",
          padding: "12px 16px",
          borderRadius: "8px",
          boxShadow: "0 4px 12px rgba(0, 0, 0, 0.3)",
          transition: "all 0.3s ease-in-out",
          "& .MuiTooltip-arrow": {
            color: "#7c3aed",
          },
        },
      },
    }}
  >
    {children}
  </Tooltip>
);

function ProductDemo() {
  // Left & Right Features Data
  const leftItems = [
    {
      icon: <SettingsIcon sx={{ color: "#c084fc", fontSize: 36, mr: 1 }} />,
      heading: "Company Management",
      description: "Easily set up branches, departments, and roles using our intuitive interface.",
    },
    {
      icon: <SecurityIcon sx={{ color: "#c084fc", fontSize: 36, mr: 1 }} />,
      heading: "Role-Based Access",
      description: "Customize user access and ensure only authorized personnel can operate.",
    },
    {
      icon: <GavelIcon sx={{ color: "#c084fc", fontSize: 36, mr: 1 }} />,
      heading: "Policy & Compliance",
      description: "Built-in tools to help you stay compliant and avoid costly penalties.",
    },
  ];

  const rightItems = [
    {
      icon: <TaskIcon sx={{ color: "#c084fc", fontSize: 36, mr: 1 }} />,
      heading: "Task Management",
      description: "Automate job creation and allocation to improve efficiency.",
    },
    {
      icon: <LocationIcon sx={{ color: "#c084fc", fontSize: 36, mr: 1 }} />,
      heading: "Geo-Tracking",
      description: "Track real-time team activities and locations with ease.",
    },
    {
      icon: <ScheduleIcon sx={{ color: "#c084fc", fontSize: 36, mr: 1 }} />,
      heading: "Scheduled Reports",
      description: "Auto-generate reports and deliver them directly to your inbox.",
    },
  ];

  const screenshotDetails = [

    {
      heading: "Laptop Dashboard",
      description: "Powerful desktop experience with advanced features and smooth performance.",
    },
    {
      heading: "Mobile Chat Interface",
      description: "Intuitive messaging layout with real-time updates and rich media support.",
    },
    {
      heading: "Group Collaboration Hub",
      description: "Manage large groups with advanced moderation tools and custom permissions.",
    },
    {
      heading: "File Sharing Dashboard",
      description: "Securely share and manage files with version control and previews.",
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isSticky, setIsSticky] = useState(false);
  const [isContentComplete, setIsContentComplete] = useState(false);
  const sectionRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current || !containerRef.current) return;

      const section = sectionRef.current;
      const container = containerRef.current;
      const rect = section.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      const winH = window.innerHeight;
      const scrollTop = window.scrollY;
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;

      // Calculate if we're in the sticky section
      const shouldBeSticky = scrollTop >= sectionTop - winH * 0.2;
      setIsSticky(shouldBeSticky);

      if (shouldBeSticky) {
        // Calculate scroll progress within the sticky section
        const scrollProgress = Math.max(
          0,
          Math.min(
            1,
            (scrollTop - sectionTop + winH * 0.5) / (sectionHeight * 1.2)
          )
        );

        // Check if all content has been viewed
        if (scrollProgress >= 0.99) {
          setIsContentComplete(true);
          return;
        } else {
          setIsContentComplete(false);
        }

        // Calculate current index based on scroll progress
        const newIndex = Math.min(
          screenshotDetails.length - 1,
          Math.floor(scrollProgress * screenshotDetails.length * 1.2)
        );
        setCurrentIndex(newIndex >= 0 ? newIndex : 0);
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll(); // Initial call
    return () => window.removeEventListener("scroll", handleScroll);
  }, [screenshotDetails.length]);

  return (
    <Box
      sx={{
        minHeight: "100vh",
        background: "linear-gradient(135deg, #4c1d95 0%, #5b21b6 50%, #312e81 100%)",
        position: "relative",
        overflow: "hidden",
        pt: 2,
      }}
      ref={containerRef}
    >
      {/* First Section: Product Introduction */}
      <Box sx={{ position: "relative", zIndex: 10, pt: 10, pb: 12 }}>
        <Container maxWidth="xl">
          <ParticleBackground count={50} speed={0.3} />
          <ScrollAnimation direction="up" distance={50} duration={0.8} delay={0.1}>
            <Grid container spacing={4} alignItems="center" justifyContent={"center"}>
              <Grid item size={{ xs: 12, md: 12 }}>
                <ScrollAnimation direction="up" distance={30} duration={0.7} delay={0.3}>
                  <Typography
                    variant="h4"
                    sx={{
                      fontWeight: "bold",
                      lineHeight: { xs: 1.1, sm: 1.2 },
                      textAlign: "center"
                    }}
                  >
                    <Box
                      component="span"
                      sx={{
                        background: "linear-gradient(to right, #c4b5fd, #f9a8d4)",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                      }}
                    >
                      Communication - Chat
                    </Box>
                  </Typography>
                </ScrollAnimation>

                <ScrollAnimation direction="up" distance={30} duration={0.6} delay={0.4}>
                  <Typography
                    variant="body1"
                    sx={{
                      color: "#e9d5ff",
                      // maxWidth: { xs: "100%", sm: "90%", md: "70%" },
                      fontSize: { xs: "0.9rem", sm: "1rem", md: "1.1rem" },
                      lineHeight: { xs: 1.5, sm: 1.6 },
                      textAlign: "center",

                    }}
                  >
                    Transform your team communication with intelligent automation. Communication - Chat Pro
                    streamlines collaboration from messaging to file sharing, working around the clock to enhance your
                    productivity.
                  </Typography>
                </ScrollAnimation>
              </Grid>
              {/* Center Video */}
              <Grid item size={{ xs: 12, md: 10 }}>
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8 }}
                  viewport={{ once: true }}
                  style={{ textAlign: "center" }}
                >
                  <video
                    src="/videos/chatvideo2.mp4"
                    autoPlay
                    loop
                    muted
                    style={{
                      width: "100%",
                      borderRadius: "16px",
                      border: "3px solid black",
                      boxShadow: "0 0 20px rgba(0,0,0,0.4)",
                    }}
                  />
                </motion.div>
              </Grid>
            </Grid>
          </ScrollAnimation>
        </Container>
      </Box>

      {/* Second Section: Sticky Screenshots */}
      <Box
        ref={sectionRef}
        sx={{
          position: "relative",
          height: `${screenshotDetails.length * 100}vh`,
          pointerEvents: isSticky && !isContentComplete ? "none" : "auto",
        }}
      >
        <Box
          sx={{
            position: isSticky ? "fixed" : "relative",
            top: isSticky ? 0 : "auto",
            left: 0,
            right: 0,
            height: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 9,
            opacity: isSticky && isContentComplete ? 0 : 1,
            transition: "opacity 0.3s ease",
          }}
        >
          <ParticleBackground count={50} speed={0.3} />
          <Container maxWidth="xl">
            <Grid container spacing={2} alignItems="center">
              <Grid item size={{ xs: 12, md: 6 }}>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentIndex}
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 50 }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                  >
                    <Typography variant="h4" sx={{ color: "white", mb: 2 }}>
                      {screenshotDetails[currentIndex].heading}
                    </Typography>
                    <Typography sx={{ color: "#e9d5ff" }}>
                      {screenshotDetails[currentIndex].description}
                    </Typography>
                  </motion.div>
                </AnimatePresence>
              </Grid>
              <Grid item size={{ xs: 12, md: 6 }}>
                <AnimatePresence mode="wait">
                  <motion.div
                    key={`img-${currentIndex}`}
                    initial={{ opacity: 0, x: 50, scale: 0.95 }}
                    animate={{ opacity: 1, x: 0, scale: 1 }}
                    exit={{ opacity: 0, x: -50, scale: 0.95 }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                  >
                    <Box
                      component="img"
                      src={`/screenshots/screenshot-${currentIndex + 1}.png`}
                      alt={screenshotDetails[currentIndex].heading}
                      sx={{
                        width: {
                          xs: "100%",     // mobile
                          sm: "90%",      // small tablet
                          md: "100%",     // medium and up
                        },
                        height: {
                          xs: "auto",     // mobile: auto height for natural aspect ratio
                          md: "65vh",     // desktop: fixed height
                        },
                        borderRadius: 4,
                        // boxShadow: 3,
                        objectFit: "contain", // or "cover" depending on image layout
                        display: "block",
                        margin: "0 auto",
                      }}
                    />

                  </motion.div>
                </AnimatePresence>
              </Grid>
            </Grid>
          </Container>
        </Box>
      </Box>

      {/* Third Section: Repeated Product Introduction */}
      <Box sx={{ position: "relative", zIndex: 10, py: 6, background: "linear-gradient(to right, #5b21b6, #4c1d95)", }}>
        <Container maxWidth="xl">
          <ParticleBackground count={50} speed={0.3} />
          <ScrollAnimation direction="up" distance={50} duration={0.8} delay={0.1}>
            <Box sx={{ textAlign: "center", mb: 8 }}>
              <Typography
                variant="h2"
                sx={{ fontSize: { xs: "2.5rem", md: "3.5rem" }, fontWeight: "bold", color: "white", mb: 2 }}
              >
                Introducing Our Product
              </Typography>
              <Box sx={{ display: "flex", justifyContent: "center" }}>
                <img
                  src="/screenshots/mobilimg.png"
                  style={{ maxWidth: "50%", height: "90vh" }}
                  alt="Communication - Chat Product"
                />
              </Box>
            </Box>
          </ScrollAnimation>
        </Container>
      </Box>

      {/* Fourth Section: Growth Metrics */}
      <Box
        sx={{
          background: "linear-gradient(135deg, #4c1d95 0%, #5b21b6 50%, #312e81 100%)",
          py: 12,
          position: "relative",
          zIndex: 10,
          overflow: "hidden",
        }}
      >
        <ParticleBackground count={50} speed={0.3} />
        <Container maxWidth="lg">
          <ScrollAnimation direction="up" distance={50} duration={0.8} delay={0.1}>
            <Grid container spacing={2} justifyContent="center" alignItems="flex-end">
              {/* Left Text */}
              <Grid item xs={12} md={3}>
                <Box sx={{ mb: { xs: 6, md: 0 } }}>
                  <Typography
                    variant="h3"
                    sx={{
                      fontWeight: "bold",
                      color: "white",
                      mb: 2,
                    }}
                  >
                    Grow<br />with Communication - Chat
                  </Typography>
                </Box>
              </Grid>

              {/* 27% Bar */}
              <Grid item xs={12} sm={4} md={3}>
                <motion.div
                  initial={{ height: 0 }}
                  whileInView={{ height: 280 }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  viewport={{ once: true, amount: 0.5 }}
                >
                  <Box
                    sx={{
                      backgroundColor: "#6d28d9",
                      borderTopLeftRadius: "120px",
                      borderTopRightRadius: "120px",
                      borderBottomLeftRadius: "0",
                      borderBottomRightRadius: "0",
                      height: "280px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      justifyContent: "flex-end",
                      pb: 4,
                      boxShadow: 3,
                    }}
                  >
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.8, delay: 1.2 }}
                      viewport={{ once: true, amount: 0.5 }}
                    >
                      <Typography variant="h4" sx={{ fontWeight: "bold", color: "white" }}>
                        27%
                      </Typography>
                      <Typography sx={{ fontWeight: "bold", color: "white" }}>
                        Increased
                      </Typography>
                      <Typography sx={{ fontWeight: "bold", color: "white" }}>
                        Productivity
                      </Typography>
                      <Typography variant="caption" sx={{ color: "#e9d5ff" }}>
                        Do more in less time
                      </Typography>
                    </motion.div>
                  </Box>
                </motion.div>
              </Grid>

              {/* 50% Bar */}
              <Grid item xs={12} sm={4} md={3}>
                <motion.div
                  initial={{ height: 0 }}
                  whileInView={{ height: 360 }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  viewport={{ once: true, amount: 0.5 }}
                >
                  <Box
                    sx={{
                      backgroundColor: "#7c3aed",
                      borderTopLeftRadius: "120px",
                      borderTopRightRadius: "120px",
                      height: "360px",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      justifyContent: "flex-end",
                      pb: 4,
                      boxShadow: 3,
                    }}
                  >
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.8, delay: 1.2 }}
                      viewport={{ once: true, amount: 0.5 }}
                    >
                      <Typography variant="h3" sx={{ fontWeight: "bold", color: "white" }}>
                        50%
                      </Typography>
                      <Typography sx={{ fontWeight: "bold", color: "white" }}>
                        Faster
                      </Typography>
                      <Typography sx={{ fontWeight: "bold", color: "white" }}>
                        Implementation
                      </Typography>
                      <Typography variant="caption" sx={{ color: "#e9d5ff" }}>
                        Get started in no time
                      </Typography>
                    </motion.div>
                  </Box>
                </motion.div>
              </Grid>

              {/* 71% Bar with image */}
              <Grid item xs={12} sm={4} md={3}>
                <motion.div
                  initial={{ height: 0 }}
                  whileInView={{ height: 460 }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  viewport={{ once: true, amount: 0.5 }}
                >
                  <Box
                    sx={{
                      backgroundColor: "#8b5cf6",
                      borderTopLeftRadius: "140px",
                      borderTopRightRadius: "140px",
                      height: "460px",
                      position: "relative",
                      textAlign: "center",
                      pb: 2,
                      boxShadow: 3,
                    }}
                  >
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.8, delay: 1.2 }}
                      viewport={{ once: true, amount: 0.5 }}
                    >
                      <Box sx={{ pt: 4 }}>
                        <Typography variant="h3" sx={{ fontWeight: "bold", color: "white" }}>
                          71%
                        </Typography>
                        <Typography sx={{ fontWeight: "bold", color: "white" }}>
                          Saved on
                        </Typography>
                        <Typography sx={{ fontWeight: "bold", color: "white" }}>
                          Licensing Fees
                        </Typography>
                        <Typography variant="caption" sx={{ color: "#e9d5ff" }}>
                          Big savings for a lifetime
                        </Typography>
                      </Box>
                    </motion.div>
                    <Box
                      component="img"
                      src="/images/woman-piggybank.png"
                      alt="Woman with piggy bank"
                      sx={{
                        position: "absolute",
                        bottom: 0,
                        left: "50%",
                        transform: "translateX(-50%)",
                        width: "100%",
                        maxHeight: "230px",
                        objectFit: "contain",
                      }}
                    />
                  </Box>
                </motion.div>
              </Grid>
            </Grid>

            {/* Footnote */}
            <Typography
              sx={{
                textAlign: "right",
                mt: 4,
                fontSize: "0.85rem",
                color: "#e9d5ff",
                fontStyle: "italic",
              }}
            >
              * Growth metrics reported by our customers in an internal survey.
            </Typography>
          </ScrollAnimation>
        </Container>
      </Box>
    </Box>
  );
}

export default ProductDemo;
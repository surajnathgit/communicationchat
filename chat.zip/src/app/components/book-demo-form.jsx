
// "use client";
// import React, { useState } from "react";
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   TextField,
//   Button,
//   FormControl,
//   InputLabel,
//   Select,
//   MenuItem,
//   FormControlLabel,
//   Checkbox,
//   Alert,
//   AlertTitle,
//   Grid,
// } from "@mui/material";
// import { CheckCircle } from "@mui/icons-material";

// const BookDemoForm = ({ onClose }) => {
//   const [formData, setFormData] = useState({
//     fullName: "",
//     workEmail: "",
//     companyName: "",
//     jobTitle: "",
//     phoneNumber: "",
//     industryType: "",
//     numberOfEmployees: "",
//     howDidYouHear: "",
//     agreeToContact: false,
//   });
//   const [showSuccess, setShowSuccess] = useState(false);
//   const [loading, setLoading] = useState(false);

//   const handleInputChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value,
//     });
//   };

//   const handleSelectChange = (name, value) => {
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleCheckboxChange = (e) => {
//     setFormData({
//       ...formData,
//       agreeToContact: e.target.checked,
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setLoading(true);

//     // Simulate API call
//     setTimeout(() => {
//       setShowSuccess(true);
//       setLoading(false);
//       setTimeout(() => {
//         setShowSuccess(false);
//         if (onClose) onClose();
//         // Reset form
//         setFormData({
//           fullName: "",
//           workEmail: "",
//           companyName: "",
//           jobTitle: "",
//           phoneNumber: "",
//           industryType: "",
//           numberOfEmployees: "",
//           howDidYouHear: "",
//           agreeToContact: false,
//         });
//       }, 2000);
//     }, 1000);
//   };

//   const isFormValid = () => {
//     return (
//       formData.fullName &&
//       formData.workEmail &&
//       formData.companyName &&
//       formData.jobTitle &&
//       formData.phoneNumber &&
//       formData.industryType &&
//       formData.numberOfEmployees &&
//       formData.howDidYouHear &&
//       formData.agreeToContact
//     );
//   };

//   const industryOptions = [
//     "Technology",
//     "Healthcare",
//     "Finance",
//     "Education",
//     "Manufacturing",
//     "Retail",
//     "Real Estate",
//     "Consulting",
//     "Government",
//     "Non-profit",
//     "Other",
//   ];

//   const employeeOptions = ["1-10", "11-50", "51-200", "201-500", "501-1000", "1000+"];

//   const hearAboutOptions = [
//     "Google Search",
//     "Social Media",
//     "Referral",
//     "Advertisement",
//     "Industry Event",
//     "Partner",
//     "Other",
//   ];

//   return (
// <Box sx={{ maxWidth: 672, mx: "auto", p: 3 }}>
//   <Card sx={{ bgcolor: "#0E1629", boxShadow: 3, border: "none" }}>
//     <CardContent
//       sx={{
//         p: 4,
//         color: "white",
//         "& .MuiInputBase-input": { color: "white" }, // Input text
//         "& .MuiInputLabel-root": { color: "white" }, // Labels
//         "& .MuiFormLabel-root.Mui-focused": { color: "white" }, // Focused label
//         "& .MuiOutlinedInput-root": {
//           "& fieldset": { borderColor: "white" }, // Input border
//           "&:hover fieldset": { borderColor: "#ddd" },
//           "&.Mui-focused fieldset": { borderColor: "white" },
//         },
//         "& .MuiSelect-icon": { color: "white" }, // Dropdown arrow
//         "& .MuiTypography-root": { color: "white" }, // Typography text
//       }}
//     >
//       <Box sx={{ textAlign: "center", mb: 4 }}>
//         <Typography variant="h5" sx={{ fontWeight: "bold" }}>
//           Book a Demo
//         </Typography>
//       </Box>

//       {showSuccess ? (
//         <Alert
//           severity="success"
//           icon={<CheckCircle />}
//           sx={{ bgcolor: "#F0FDF4", border: "1px solid #BBF7D0", mb: 2 }}
//         >
//           <AlertTitle sx={{ color: "#15803D" }}>
//             Thank you! We'll contact you soon to schedule your demo.
//           </AlertTitle>
//         </Alert>
//       ) : (
//         <form onSubmit={handleSubmit}>
//           <Grid container spacing={2}>
//             <Grid item xs={12} md={6}>
//               <TextField
//                 id="fullName"
//                 name="fullName"
//                 label="Full Name *"
//                 value={formData.fullName}
//                 onChange={handleInputChange}
//                 placeholder="Enter full name"
//                 required
//                 fullWidth
//                 sx={{ mb: 2 }}
//               />
//             </Grid>
//             <Grid item xs={12} md={6}>
//               <TextField
//                 id="workEmail"
//                 name="workEmail"
//                 type="email"
//                 label="Work Email *"
//                 value={formData.workEmail}
//                 onChange={handleInputChange}
//                 placeholder="Enter work email"
//                 required
//                 fullWidth
//                 sx={{ mb: 2 }}
//               />
//             </Grid>

//             <Grid item xs={12} md={6}>
//               <TextField
//                 id="companyName"
//                 name="companyName"
//                 label="Company Name *"
//                 value={formData.companyName}
//                 onChange={handleInputChange}
//                 placeholder="Enter company name"
//                 required
//                 fullWidth
//                 sx={{ mb: 2 }}
//               />
//             </Grid>
//             <Grid item xs={12} md={6}>
//               <TextField
//                 id="jobTitle"
//                 name="jobTitle"
//                 label="Job Title / Role *"
//                 value={formData.jobTitle}
//                 onChange={handleInputChange}
//                 placeholder="Enter job title / role"
//                 required
//                 fullWidth
//                 sx={{ mb: 2 }}
//               />
//             </Grid>

//             <Grid item xs={12} md={6}>
//               <TextField
//                 id="phoneNumber"
//                 name="phoneNumber"
//                 type="tel"
//                 label="Phone Number *"
//                 value={formData.phoneNumber}
//                 onChange={handleInputChange}
//                 placeholder="Enter phone number"
//                 required
//                 fullWidth
//                 sx={{ mb: 2 }}
//               />
//             </Grid>
//             <Grid item xs={12} md={6}>
//               <FormControl fullWidth sx={{ mb: 2 }}>
//                 <InputLabel id="industryType-label">Industry Type *</InputLabel>
//                 <Select
//                   labelId="industryType-label"
//                   id="industryType"
//                   value={formData.industryType}
//                   label="Industry Type *"
//                   onChange={(e) => handleSelectChange("industryType", e.target.value)}
//                 >
//                   <MenuItem value="">
//                     <em>Select industry</em>
//                   </MenuItem>
//                   {industryOptions.map((industry) => (
//                     <MenuItem key={industry} value={industry}>
//                       {industry}
//                     </MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </Grid>

//             <Grid item xs={12} md={6}>
//               <FormControl fullWidth sx={{ mb: 2 }}>
//                 <InputLabel id="numberOfEmployees-label">Number of Employees *</InputLabel>
//                 <Select
//                   labelId="numberOfEmployees-label"
//                   id="numberOfEmployees"
//                   value={formData.numberOfEmployees}
//                   label="Number of Employees *"
//                   onChange={(e) => handleSelectChange("numberOfEmployees", e.target.value)}
//                 >
//                   <MenuItem value="">
//                     <em>Select number</em>
//                   </MenuItem>
//                   {employeeOptions.map((option) => (
//                     <MenuItem key={option} value={option}>
//                       {option}
//                     </MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </Grid>
//             <Grid item xs={12} md={6}>
//               <FormControl fullWidth sx={{ mb: 2 }}>
//                 <InputLabel id="howDidYouHear-label">How Did You Hear About Us? *</InputLabel>
//                 <Select
//                   labelId="howDidYouHear-label"
//                   id="howDidYouHear"
//                   value={formData.howDidYouHear}
//                   label="How Did You Hear About Us? *"
//                   onChange={(e) => handleSelectChange("howDidYouHear", e.target.value)}
//                 >
//                   <MenuItem value="">
//                     <em>Select how</em>
//                   </MenuItem>
//                   {hearAboutOptions.map((option) => (
//                     <MenuItem key={option} value={option}>
//                       {option}
//                     </MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </Grid>

//             <Grid item xs={12}>
//               <FormControlLabel
//                 control={
//                   <Checkbox
//                     id="agreeToContact"
//                     checked={formData.agreeToContact}
//                     onChange={handleCheckboxChange}
//                   />
//                 }
//                 label="I agree to be contacted by SecureChat Pro for demo and updates"
//                 sx={{ mb: 2 }}
//               />
//             </Grid>

//             <Grid item xs={12}>
//               <Box sx={{ display: "flex", gap: 2, pt: 2 }}>
//                 <Button
//                   variant="outlined"
//                   onClick={onClose}
//                   sx={{ flex: 1, color: "#374151", borderColor: "#D1D5DB" }}
//                 >
//                   Cancel
//                 </Button>
//                 <Button
//                   type="submit"
//                   variant="contained"
//                   disabled={loading || !isFormValid()}
//                   sx={{ flex: 1, bgcolor: "#2563EB", "&:hover": { bgcolor: "#1E40AF" } }}
//                 >
//                   {loading ? "Booking Demo..." : "Book Demo"}
//                 </Button>
//               </Box>
//             </Grid>
//           </Grid>
//         </form>
//       )}
//     </CardContent>
//   </Card>
// </Box>

//   );
// };

// export default BookDemoForm;


"use client"

import { useState, useEffect } from "react"
import {
  Modal,
  TextField,
  FormControl,
  Select,
  Backdrop,
  Paper,
  Snackbar,
  Alert,
  Checkbox,
  FormControlLabel,
  CircularProgress,
  Box,
  Typography,
  IconButton,
  Button,
  MenuItem
} from "@mui/material"
import CloseIcon from "@mui/icons-material/Close"
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown"

const BookDemoForm = ({ open, onClose }) => {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    fullName: "",
    workEmail: "",
    companyName: "",
    phoneNumber: "",
    jobTitle: "",
    numberOfEmployees: "",
    industryType: "",
    otherIndustry: "",
    howDidYouHearAboutUs: "",
    consent: false,
  })
  const [snackbarOpen, setSnackbarOpen] = useState(false)
  const [snackbarMessage, setSnackbarMessage] = useState("")
  const [snackbarSeverity, setSnackbarSeverity] = useState("success")
  const [showThankYou, setShowThankYou] = useState(false)

  // Industry options
  const industryOptions = [
    "Technology",
    "Healthcare",
    "Finance",
    "Education",
    "Manufacturing",
    "Retail",
    "Consulting",
    "Real Estate",
    "Media & Entertainment",
    "Other",
  ]

  // Employee count options
  const employeeOptions = ["1-10", "11-50", "51-200", "201-500", "501-1000", "1000+"]

  // How did you hear about us options
  const hearAboutUsOptions = [
    "Google Search",
    "Social Media",
    "HR Conclave",
    "Referral",
    "Advertisement",
    "Blog/Article",
    "Other",
  ]

  const handleFormChange = (event) => { 
    const { name, value, type, checked } = event.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))
  }

  const parseApiError = async (response) => {
    try {
      const errorData = await response.json()
      return errorData.message || "Failed to schedule demo. Please try again."
    } catch {
      return "Failed to schedule demo. Please try again."
    }
  }

  const handleFormSubmit = async (event) => {
    event.preventDefault()
    setLoading(true)

    // Enhanced client-side validation
    if (!formData.consent) {
      setSnackbarMessage("You must agree to be contacted")
      setSnackbarSeverity("error")
      setSnackbarOpen(true)
      setLoading(false)
      return
    }

    // Phone number validation - ensure it's exactly 10 digits
    const phoneRegex = /^\d{10}$/
    if (!phoneRegex.test(formData.phoneNumber)) {
      setSnackbarMessage("Phone number must be exactly 10 digits")
      setSnackbarSeverity("error")
      setSnackbarOpen(true)
      setLoading(false)
      return
    }

    // Prepare payload with consistent property naming
    const payload = {
      fullName: formData.fullName.trim(),
      workEmail: formData.workEmail.trim(),
      companyName: formData.companyName.trim(),
      phoneNumber: formData.phoneNumber,
      jobTitle: formData.jobTitle.trim(),
      numberOfEmployees: formData.numberOfEmployees,
      industryType: formData.industryType === "Other" ? formData.otherIndustry.trim() : formData.industryType,
      howDidYouHearAboutUs: formData.howDidYouHearAboutUs,
      consent: formData.consent
    }

    try {
      const response = await fetch("https://api.recruitexe.com/v1/api/demo/createBookDemo", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      if (!response.ok) {
        const errorMessage = await parseApiError(response)
        throw new Error(errorMessage)
      }

      // Handle successful response
      const responseData = await response.json()
      console.log("API Response:", responseData)
      
      // Show thank you message
      setShowThankYou(true)
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setFormData({
          fullName: "",
          workEmail: "",
          companyName: "",
          phoneNumber: "",
          jobTitle: "",
          numberOfEmployees: "",
          industryType: "",
          otherIndustry: "",
          howDidYouHearAboutUs: "",
          consent: false,
        })
        setShowThankYou(false)
        onClose()
      }, 3000)
      
    } catch (error) {
      console.error("Error:", error.message)
      setSnackbarMessage(error.message || "Network error. Please check your connection and try again.")
      setSnackbarSeverity("error")
      setSnackbarOpen(true)
    } finally {
      setLoading(false)
    }
  }

  const handleSnackbarClose = () => {
    setSnackbarOpen(false)
  }

  // Common TextField styles
  const textFieldStyles = {
    "& .MuiOutlinedInput-root": {
      borderRadius: 3,
      backgroundColor: "#f8fafc",
      border: "1px solid #e2e8f0",
      fontFamily: '"Inter", sans-serif',
      fontSize: "0.95rem",
      "&:hover": {
        backgroundColor: "#f1f5f9",
        "& fieldset": {
          borderColor: "#cbd5e1",
        },
      },
      "&.Mui-focused": {
        backgroundColor: "white",
        "& fieldset": {
          borderColor: "#10b981",
          borderWidth: "2px",
        },
      },
      "& fieldset": {
        border: "none",
      },
    },
    "& .MuiOutlinedInput-input": {
      padding: "16px 18px",
      fontSize: "0.95rem",
      color: "#1e293b",
      "&::placeholder": {
        color: "#94a3b8",
        opacity: 1,
      },
    },
  }

  // Common Select styles
  const selectStyles = {
    borderRadius: 3,
    backgroundColor: "#f8fafc",
    border: "1px solid #e2e8f0",
    fontFamily: '"Inter", sans-serif',
    fontSize: "0.95rem",
    "& .MuiSelect-select": {
      padding: "16px 18px",
      fontSize: "0.95rem",
      color: "#1e293b",
    },
    "&:hover": {
      backgroundColor: "#f1f5f9",
      "& .MuiOutlinedInput-notchedOutline": {
        borderColor: "#cbd5e1",
      },
    },
    "&.Mui-focused": {
      backgroundColor: "white",
      "& .MuiOutlinedInput-notchedOutline": {
        borderColor: "#10b981",
        borderWidth: "2px",
      },
    },
    "& .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
    "& .MuiSelect-icon": {
      color: "#94a3b8",
      right: 12,
    },
  }

  // Common MenuItem styles
  const menuItemStyles = {
    fontFamily: '"Inter", sans-serif',
    fontSize: "0.95rem",
    padding: "12px 18px",
    "&:hover": {
      backgroundColor: "#f8fafc",
    },
  }

  return (
    <>
      <Modal
        open={open}
        onClose={onClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
          sx: {
            backgroundColor: "rgba(0, 0, 0, 0.4)",
          },
        }}
      >
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: { xs: "95%", sm: "90%", md: "900px" },
            maxHeight: "95vh",
            overflow: "auto",
            outline: "none",
          }}
        >
          <Paper
            elevation={0}
            sx={{
              p: { xs: 4, sm: 5, md: 6 },
              borderRadius: 3,
              position: "relative",
              backgroundColor: "white",
              border: "1px solid #e2e8f0",
              boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
              fontFamily: '"Inter", sans-serif',
            }}
          >
            {/* Close Button */}
            <IconButton
              onClick={onClose}
              sx={{
                position: "absolute",
                right: 20,
                top: 20,
                color: "#94a3b8",
                backgroundColor: "transparent",
                "&:hover": {
                  backgroundColor: "#f8fafc",
                  color: "#64748b",
                },
              }}
            >
              <CloseIcon fontSize="medium" />
            </IconButton>

            {/* Modal Header */}
            <Box sx={{ mb: 6, textAlign: "center" }}>
              <Typography
                variant="h4"
                component="h2"
                sx={{
                  fontWeight: 700,
                  mb: 2,
                  color: "#10b981",
                  fontSize: { xs: "2rem", md: "2.5rem" },
                  fontFamily: '"Inter", sans-serif',
                }}
              >
                {showThankYou ? (
                  `Thank You, ${formData.fullName || 'User'}!`
                ) : formData.fullName ? (
                  `Hi ${formData.fullName}, Let's Schedule Your Demo`
                ) : (
                  "Book a Demo"
                )}
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  color: "#94a3b8",
                  fontSize: "1.1rem",
                  fontFamily: '"Inter", sans-serif',
                  fontWeight: 400,
                }}
              >
                {showThankYou ? (
                  "We'll contact you shortly to confirm your demo schedule."
                ) : (
                  "Let's schedule a personalized demo for your team"
                )}
              </Typography>
            </Box>

            {!showThankYou ? (
              /* Form */
              <Box component="form" onSubmit={handleFormSubmit} sx={{ display: "flex", flexDirection: "column", gap: 3 }}>
                {/* First Row - Full Name and Work Email */}
                <Box sx={{ display: "flex", gap: 3 }}>
                  <TextField
                    required
                    fullWidth
                    name="fullName"
                    placeholder="Full Name *"
                    value={formData.fullName}
                    onChange={handleFormChange}
                    variant="outlined"
                    sx={textFieldStyles}
                  />
                  <TextField
                    required
                    fullWidth
                    name="workEmail"
                    type="email"
                    placeholder="Work Email *"
                    value={formData.workEmail}
                    onChange={handleFormChange}
                    variant="outlined"
                    sx={textFieldStyles}
                  />
                </Box>

                {/* Second Row - Company Name and Job Title */}
                <Box sx={{ display: "flex", gap: 3 }}>
                  <TextField
                    required
                    fullWidth
                    name="companyName"
                    placeholder="Company Name *"
                    value={formData.companyName}
                    onChange={handleFormChange}
                    variant="outlined"
                    sx={textFieldStyles}
                  />
                  <TextField
                    required
                    fullWidth
                    name="jobTitle"
                    placeholder="Job Title *"
                    value={formData.jobTitle}
                    onChange={handleFormChange}
                    variant="outlined"
                    sx={textFieldStyles}
                  />
                </Box>

                {/* Third Row - Phone Number and Industry Type */}
                <Box sx={{ display: "flex", gap: 3 }}>
                  <Box sx={{ flex: 1 }}>
                    <TextField
                      required
                      fullWidth
                      name="phoneNumber"
                      type="tel"
                      placeholder="Phone Number *"
                      value={formData.phoneNumber}
                      onChange={handleFormChange}
                      variant="outlined"
                      inputProps={{ maxLength: 10 }}
                      sx={textFieldStyles}
                    />
                    <Typography
                      variant="caption"
                      sx={{
                        color: "#94a3b8",
                        mt: 1,
                        display: "block",
                        fontSize: "0.8rem",
                        fontFamily: '"Inter", sans-serif',
                      }}
                    >
                      {formData.phoneNumber.length}/10 digits
                    </Typography>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <FormControl fullWidth>
                      <Select
                        required
                        name="industryType"
                        value={formData.industryType}
                        onChange={handleFormChange}
                        displayEmpty
                        IconComponent={KeyboardArrowDownIcon}
                        sx={selectStyles}
                        MenuProps={{
                          PaperProps: {
                            sx: {
                              maxHeight: 300,
                              mt: 1,
                              borderRadius: 2,
                              border: "1px solid #e2e8f0",
                              boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
                            },
                          },
                        }}
                      >
                        <MenuItem
                          value=""
                          disabled
                          sx={{
                            fontFamily: '"Inter", sans-serif',
                            fontSize: "0.95rem",
                            color: "#94a3b8",
                            padding: "12px 18px",
                          }}
                        >
                          Industry Type *
                        </MenuItem>
                        {industryOptions.map((option) => (
                          <MenuItem key={option} value={option} sx={menuItemStyles}>
                            {option}
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                    {formData.industryType === "Other" && (
                      <TextField
                        required
                        fullWidth
                        name="otherIndustry"
                        placeholder="Please specify your industry *"
                        value={formData.otherIndustry}
                        onChange={handleFormChange}
                        variant="outlined"
                        sx={{ ...textFieldStyles, mt: 3 }}
                      />
                    )}
                  </Box>
                </Box>

                {/* Fourth Row - Number of Employees and How Did You Hear About Us */}
                <Box sx={{ display: "flex", gap: 3 }}>
                  <FormControl fullWidth sx={{ flex: 1 }}>
                    <Select
                      required
                      name="numberOfEmployees"
                      value={formData.numberOfEmployees}
                      onChange={handleFormChange}
                      displayEmpty
                      IconComponent={KeyboardArrowDownIcon}
                      sx={selectStyles}
                      MenuProps={{
                        PaperProps: {
                          sx: {
                            maxHeight: 300,
                            mt: 1,
                            borderRadius: 2,
                            border: "1px solid #e2e8f0",
                            boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
                          },
                        },
                      }}
                    >
                      <MenuItem
                        value=""
                        disabled
                        sx={{
                          fontFamily: '"Inter", sans-serif',
                          fontSize: "0.95rem",
                          color: "#94a3b8",
                          padding: "12px 18px",
                        }}
                      >
                        Number of Employees *
                      </MenuItem>
                      {employeeOptions.map((option) => (
                        <MenuItem key={option} value={option} sx={menuItemStyles}>
                          {option}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl fullWidth sx={{ flex: 1 }}>
                    <Select
                      required
                      name="howDidYouHearAboutUs"
                      value={formData.howDidYouHearAboutUs}
                      onChange={handleFormChange}
                      displayEmpty
                      IconComponent={KeyboardArrowDownIcon}
                      sx={selectStyles}
                      MenuProps={{
                        PaperProps: {
                          sx: {
                            maxHeight: 300,
                            mt: 1,
                            borderRadius: 2,
                            border: "1px solid #e2e8f0",
                            boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
                          },
                        },
                      }}
                    >
                      <MenuItem
                        value=""
                        disabled
                        sx={{
                          fontFamily: '"Inter", sans-serif',
                          fontSize: "0.95rem",
                          color: "#94a3b8",
                          padding: "12px 18px",
                        }}
                      >
                        How Did You Hear About Us? *
                      </MenuItem>
                      {hearAboutUsOptions.map((option) => (
                        <MenuItem key={option} value={option} sx={menuItemStyles}>
                          {option}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Box>

                {/* Consent Checkbox */}
                <FormControlLabel
                  control={
                    <Checkbox
                      required
                      name="consent"
                      checked={formData.consent}
                      onChange={handleFormChange}
                      sx={{
                        color: "#cbd5e1",
                        "&.Mui-checked": {
                          color: "#10b981",
                        },
                        "& .MuiSvgIcon-root": {
                          fontSize: 20,
                        },
                      }}
                    />
                  }
                  label={
                    <Typography
                      variant="body2"
                      sx={{
                        color: "#94a3b8",
                        fontSize: "0.9rem",
                        fontFamily: '"Inter", sans-serif',
                        fontWeight: 400,
                      }}
                    >
                      I agree to be contacted by RecruitExe for demo and updates *
                    </Typography>
                  }
                  sx={{
                    alignItems: "flex-start",
                    mt: 1,
                  }}
                />

                {/* Submit Button */}
                <Box sx={{ mt: 3 }}>
                  <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    disabled={loading}
                    sx={{
                      py: 2,
                      borderRadius: 3,
                      fontWeight: 600,
                      fontSize: "1rem",
                      textTransform: "none",
                      backgroundColor: "#10b981",
                      color: "white",
                      fontFamily: '"Inter", sans-serif',
                      boxShadow: "0 4px 12px rgba(16, 185, 129, 0.3)",
                      "&:hover": {
                        backgroundColor: "#059669",
                        boxShadow: "0 6px 16px rgba(16, 185, 129, 0.4)",
                      },
                      "&:disabled": {
                        backgroundColor: "#e2e8f0",
                        color: "#94a3b8",
                        boxShadow: "none",
                      },
                    }}
                  >
                    {loading ? <CircularProgress size={24} color="inherit" /> : "Book Demo"}
                  </Button>
                </Box>
              </Box>
            ) : (
              /* Thank You Message */
              <Box sx={{ textAlign: "center", py: 4 }}>
                <Typography
                  variant="h5"
                  sx={{
                    color: "#10b981",
                    mb: 3,
                    fontFamily: '"Inter", sans-serif',
                    fontWeight: 600,
                  }}
                >
                  Your demo request has been received!
                </Typography>
                <Typography
                  variant="body1"
                  sx={{
                    color: "#64748b",
                    fontFamily: '"Inter", sans-serif',
                  }}
                >
                  Our team will reach out to you shortly to confirm the details.
                </Typography>
                <Button
                  onClick={onClose}
                  variant="outlined"
                  sx={{
                    mt: 4,
                    px: 4,
                    py: 1.5,
                    borderRadius: 3,
                    fontWeight: 600,
                    fontSize: "0.95rem",
                    textTransform: "none",
                    color: "#10b981",
                    borderColor: "#10b981",
                    fontFamily: '"Inter", sans-serif',
                    "&:hover": {
                      backgroundColor: "#f0fdf4",
                      borderColor: "#059669",
                    },
                  }}
                >
                  Close
                </Button>
              </Box>
            )}
          </Paper>
        </Box>
      </Modal>

      {/* Success/Error Snackbar */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity={snackbarSeverity}
          sx={{
            width: "100%",
            fontFamily: '"Inter", sans-serif',
            borderRadius: 2,
          }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </>
  )
}

export default BookDemoForm

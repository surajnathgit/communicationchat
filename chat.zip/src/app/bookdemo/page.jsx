import React from 'react';
import { Box, Container } from '@mui/material';
import BookDemoForm from '../components/book-demo-form';
import ParticleBackground from '../components/particle-background';

export default function BookDemoPage() {
  return (
<Box
  sx={{
    minHeight: '100vh',
    background: "linear-gradient(135deg, #4c1d95 0%, #5b21b6 50%, #312e81 100%)",
    position: 'relative',
    overflow: 'hidden',
    py: 6,
    '&::before': {
      content: '""',
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      backdropFilter: 'blur(8px)', // Apply blur
      WebkitBackdropFilter: 'blur(8px)', // Safari support
      zIndex: 0,
    },
  }}
>
      {/* Particle Background */}
      <ParticleBackground  speed={0.3} />
      <Container
        sx={{
          position: 'relative',
          zIndex: 10,
        }}
      >
        <BookDemoForm />
      </Container>
    </Box>
  );
}